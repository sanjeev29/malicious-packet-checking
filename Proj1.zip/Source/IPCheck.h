#include <iostream>
#include <string>
#include <bitset>

#include "sha256.h"
#include "RBFGen.h"

using namespace std;

bool check_ips(RBF &curr_RBF, string IP);